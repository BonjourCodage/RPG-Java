package rpg;

public class Food extends Item {

    private final String name;

    public Food(String name) {
        super();
        this.name = name;
    }
}