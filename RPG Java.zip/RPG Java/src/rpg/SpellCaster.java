package rpg;

public abstract class SpellCaster extends Hero {
    int manaPoints;
    int manaCost;
    int ArrowCounts;
    int ArrowCost;

}