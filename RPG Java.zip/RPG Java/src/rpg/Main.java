package rpg;

public class Main {
    public static void main(String[] args) {
        System.out.println("Salutation à toi pour cette nouvelle aventure");
        Game mainGame = new Game();
        mainGame.start();
    }
}



