package rpg;

public abstract class Spell extends SpellCaster {
    int lifepoints;
    String name;
    String description;

}
